﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LoadImageFile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Load and display an image file.
        private void Form1_Load(object sender, EventArgs e)
        {
            try 
            {	        
                string file_name = Application.StartupPath;
                if (file_name.EndsWith("\\bin\\Debug"))
                {
                    file_name = file_name.Substring(0, file_name.LastIndexOf("\\bin\\Debug"));
                }
                file_name += "\\Test.bmp";

                // Load and display the image.
#if (false)
                // Locks the file.
                Bitmap bm = new Bitmap(file_name);
#else
                // Doesn't lock the file.
                Bitmap original_bm = new Bitmap(file_name);
                Bitmap bm = new Bitmap(original_bm.Width, original_bm.Height);
                using (Graphics gr = Graphics.FromImage(bm))
                {
                    gr.DrawImageUnscaled(original_bm, 0, 0);
                }
                original_bm.Dispose();
                original_bm = null;
#endif

                // Display the image in a PictureBox.
                picTest.Image = bm;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening file\n" + ex.Message);
            }
        }
    }
}
