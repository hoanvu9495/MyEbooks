﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace MakeBitmap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Create and display a bitmap.
        private void Form1_Load(object sender, EventArgs e)
        {
            // Make the Bitmap.
            Bitmap bm = new Bitmap(200, 150);

            // Make an associated Graphics object.
            using (Graphics gr = Graphics.FromImage(bm))
            {
                // Draw.
                gr.SmoothingMode = SmoothingMode.AntiAlias;
                gr.Clear(Color.Yellow);
                using (Pen thick_pen = new Pen(Color.Red, 5))
                {
                    gr.DrawEllipse(thick_pen, 3, 3, 195, 145);

                    thick_pen.Color = Color.Green;
                    gr.DrawLine(thick_pen, 3, 3, 197, 147);

                    thick_pen.Color = Color.Blue;
                    gr.DrawLine(thick_pen, 3, 147, 197, 3);
                }
            }

            // Display the result in a PictureBox.
            picResult.Image = bm;
        }
    }
}
