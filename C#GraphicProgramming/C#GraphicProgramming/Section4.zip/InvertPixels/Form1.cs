﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Imaging;

namespace InvertPixels
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Load an image.
        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            if (ofdImage.ShowDialog() == DialogResult.OK)
            {
                try 
                {	        
                    // Load and display the image without locking the file.
                    Bitmap original_bm = new Bitmap(ofdImage.FileName);
                    Bitmap bm = new Bitmap(original_bm.Width, original_bm.Height);
                    using (Graphics gr = Graphics.FromImage(bm))
                    {
                        gr.DrawImageUnscaled(original_bm, 0, 0);
                    }
                    original_bm.Dispose();
                    original_bm = null;
                    picOriginal.Image = bm;

                    // Size and position the inverted PictureBox, and size the form.
                    picInverted.SetBounds(
                        picOriginal.Right + 10, picOriginal.Top,
                        picOriginal.Width, picOriginal.Height);
                    picInverted.Image = null;
                    this.ClientSize = new Size(picInverted.Right, picInverted.Bottom);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error opening file " + ofdImage.FileName + "\n" + ex.Message);
                }
            }
        }

        // Save the result bitmap.
        private void mnuFileSaveAs_Click(object sender, EventArgs e)
        {
            if (sfdImage.ShowDialog() == DialogResult.OK)
            {
                try 
	            {	        
                    Bitmap bm = (Bitmap)picInverted.Image;
                    string file_name = sfdImage.FileName;
                    string ext = file_name.Substring(file_name.LastIndexOf(".")).ToLower();
                    switch (ext)
                    {
                        case ".bmp":
                            bm.Save(file_name, ImageFormat.Bmp);
                            break;
                        case ".gif":
                            bm.Save(file_name, ImageFormat.Gif);
                            break;
                        case ".jpg":
                        case ".jpeg":
                            bm.Save(file_name, ImageFormat.Jpeg);
                            break;
                        case ".png":
                            bm.Save(file_name, ImageFormat.Png);
                            break;
                        case ".tif":
                        case ".tiff":
                            bm.Save(file_name, ImageFormat.Tiff);
                            break;
	                    default:
                            MessageBox.Show("Unknown file extension " + ext);
                            return;
                    }
                    MessageBox.Show("Ok", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
	            }
	            catch (Exception ex)
	            {
                    MessageBox.Show("Error opening file " + ofdImage.FileName + "\n" + ex.Message);
	            }
            }
        }

        // Invert the image.
        private void mnuDataInvert_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            Application.DoEvents();

            Bitmap bm = (Bitmap)(picOriginal.Image.Clone());
            Color old_clr, new_clr;

            // Invert the pixels in the upper left quadrant.
            int x2 = bm.Width - 1;
            int y2 = bm.Height - 1;
            int x1 = (int)(x2 / 2);
            int y1 = (int)(y2 / 2);
            for (int x = 0; x <= x1; x++)
            {
                for (int y = 0; y <= y1; y++)
                {
                    old_clr = bm.GetPixel(x, y);
                    new_clr = Color.FromArgb(255, 255 - old_clr.R, 255 - old_clr.G, 255 - old_clr.B);
                    bm.SetPixel(x, y, new_clr);
                }
            }

            // Invert the pixels in the lower right quadrant.
            for (int x = x1 + 1; x <= x2; x++)
            {
                for (int y = y1 + 1; y <= y2; y++)
                {
                    old_clr = bm.GetPixel(x, y);
                    new_clr = Color.FromArgb(255, 255 - old_clr.R, 255 - old_clr.G, 255 - old_clr.B);
                    bm.SetPixel(x, y, new_clr);
                }
            }

            // Draw a bit.
            using (Graphics gr = Graphics.FromImage(bm))
            {
                using (Pen thick_pen = new Pen(Color.Red, 5))
                {
                    gr.DrawRectangle(thick_pen, 0, 0, x1, y1);
                    gr.DrawRectangle(thick_pen, x1, y1, x1, y1);
                }
            }

            // Display the result.
            picInverted.Image = bm;

            this.Cursor = Cursors.Default;
        }
    }
}
