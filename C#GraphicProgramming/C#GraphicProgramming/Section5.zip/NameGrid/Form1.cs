﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Text;
using System.Drawing.Drawing2D;

namespace NameGrid
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw a grid with players names across the left and top.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

            const int GAP = 30;
            string[] players = {"Archer", "Bezoar", "Chumley", "Deemers", "Everly"};

            // Draw the grid.
            int xmin = 100;
            int ymin = 75;
            int xmax = xmin + players.Length * GAP;
            int ymax = ymin + players.Length * GAP;

            // Draw gridlines.
            for (int i = 0; i <= players.Length; i++)
            {
                e.Graphics.DrawLine(Pens.Green, xmin, ymin + i * GAP, xmax, ymin + i * GAP);
                e.Graphics.DrawLine(Pens.Green, xmin + i * GAP, ymin, xmin + i * GAP, ymax);
            }

            using (Font the_font = new Font("Comic Sans MS", 15))
            {
                // Draw names on the left.
                for (int i = 0; i < players.Length; i++)
                {
                    e.Graphics.FillRectangle(Brushes.Green, xmin + i * GAP, ymin + i * GAP, GAP, GAP);
                    e.Graphics.DrawString(players[i], the_font, Brushes.Blue, 4, ymin + i * GAP);
                }

                // Draw names across the top.
                for (int i = 0; i < players.Length; i++)
                {
                    e.Graphics.RotateTransform(-45);
                    e.Graphics.TranslateTransform(xmin + i * GAP, (int)(ymin - GAP / 2), MatrixOrder.Append);
                    e.Graphics.DrawString(players[i], the_font, Brushes.Blue, 0, 0);
                    e.Graphics.ResetTransform();
                }
            }
        }
    }
}
