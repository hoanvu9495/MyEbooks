﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Text;
using System.Drawing.Drawing2D;

namespace TransformedText
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw a transformed bitmap and transformed text.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;

            e.Graphics.TranslateTransform(
                -Properties.Resources.Smiley.Width / 2,
                -Properties.Resources.Smiley.Height / 2);
            e.Graphics.ScaleTransform(1.5f, 1f, MatrixOrder.Append);
            e.Graphics.RotateTransform(-30, MatrixOrder.Append);
            e.Graphics.TranslateTransform(220, 150, MatrixOrder.Append);
            e.Graphics.DrawImageUnscaled(Properties.Resources.Smiley, 0, 0);
            e.Graphics.ResetTransform();

            using (Font the_font = new Font("Times New Roman", 16))
            {
                e.Graphics.ScaleTransform(1, 4);
                e.Graphics.TranslateTransform(10, 10, MatrixOrder.Append);
                e.Graphics.DrawString("Tall And Thin", the_font, Brushes.Blue, 0, 0);
                e.Graphics.ResetTransform();

                e.Graphics.RotateTransform(45);
                e.Graphics.TranslateTransform(30, 90, MatrixOrder.Append);
                e.Graphics.DrawString("Rotated 45", the_font, Brushes.Blue, 0, 0);
                e.Graphics.ResetTransform();

                e.Graphics.RotateTransform(-90);
                e.Graphics.TranslateTransform(100, 200, MatrixOrder.Append);
                e.Graphics.DrawString("Rotated -90", the_font, Brushes.Blue, 0, 0);
                e.Graphics.ResetTransform();

                e.Graphics.ScaleTransform(4, 1);
                e.Graphics.TranslateTransform(140, 10, MatrixOrder.Append);
                using (StringFormat sf = new StringFormat())
                {
                    sf.Alignment = StringAlignment.Center;
                    sf.LineAlignment = StringAlignment.Near;
                    Rectangle rect = new Rectangle(0, 0, 60, 80);
                    e.Graphics.DrawString("Short And Wide", the_font, Brushes.Blue, rect, sf);
                    e.Graphics.DrawRectangle(Pens.Red, rect);
                }
                e.Graphics.ResetTransform();
            }
        }
    }
}
