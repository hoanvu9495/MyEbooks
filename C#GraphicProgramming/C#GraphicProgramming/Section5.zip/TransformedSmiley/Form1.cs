﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace TransformedSmiley
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw a smiley face in -1 <= x <= 1, -1 <= y <= 1.
        private void DrawSmiley(Graphics gr)
        {
            using (Pen thin_pen = new Pen(Color.Blue, 0))
            {
                gr.FillEllipse(Brushes.Yellow, -1, -1, 2, 2);
                gr.DrawEllipse(thin_pen, -1, -1, 2, 2);
                gr.DrawArc(thin_pen, -0.75f, -0.75f, 1.5f, 1.5f, 0, 180);
                gr.FillEllipse(Brushes.Red, -0.2f, -0.2f, 0.4f, 0.6F);
                gr.FillEllipse(Brushes.White, -0.5f, -0.6f, 0.3f, 0.5F);
                gr.DrawEllipse(thin_pen, -0.5f, -0.6f, 0.3f, 0.5F);
                gr.FillEllipse(Brushes.Black, -0.4f, -0.5f, 0.2f, 0.3F);
                gr.FillEllipse(Brushes.White, 0.2f, -0.6f, 0.3f, 0.5F);
                gr.DrawEllipse(thin_pen, 0.2f, -0.6f, 0.3f, 0.5F);
                gr.FillEllipse(Brushes.Black, 0.3f, -0.5f, 0.2f, 0.3F);
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Draw 50x50 pixels.
            e.Graphics.ScaleTransform(50, 50);
            e.Graphics.TranslateTransform(60, 60, MatrixOrder.Append);
            DrawSmiley(e.Graphics);
            e.Graphics.ResetTransform();

            // Draw 50x100 pixels.
            e.Graphics.ScaleTransform(50, 100);
            e.Graphics.TranslateTransform(170, 110, MatrixOrder.Append);
            DrawSmiley(e.Graphics);
            e.Graphics.ResetTransform();

            // Draw 50x30 pixels rotated and flipped vertically.
            e.Graphics.RotateTransform(45, MatrixOrder.Append);
            e.Graphics.ScaleTransform(50, -30, MatrixOrder.Append);
            e.Graphics.TranslateTransform(60, 170, MatrixOrder.Append);
            DrawSmiley(e.Graphics);
            e.Graphics.ResetTransform();
        }
    }
}
