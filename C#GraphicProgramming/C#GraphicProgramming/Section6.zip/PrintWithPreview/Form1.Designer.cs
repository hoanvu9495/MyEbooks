﻿namespace PrintWithPreview
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnPreview = new System.Windows.Forms.Button();
            this.ppdShapes = new System.Windows.Forms.PrintPreviewDialog();
            this.pdShapes = new System.Drawing.Printing.PrintDocument();
            this.SuspendLayout();
            // 
            // btnPrint
            // 
            this.btnPrint.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPrint.Location = new System.Drawing.Point(166, 46);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(88, 32);
            this.btnPrint.TabIndex = 3;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnPreview
            // 
            this.btnPreview.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPreview.Location = new System.Drawing.Point(38, 46);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(88, 32);
            this.btnPreview.TabIndex = 2;
            this.btnPreview.Text = "Preview";
            this.btnPreview.UseVisualStyleBackColor = true;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // ppdShapes
            // 
            this.ppdShapes.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.ppdShapes.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.ppdShapes.ClientSize = new System.Drawing.Size(400, 300);
            this.ppdShapes.Document = this.pdShapes;
            this.ppdShapes.Enabled = true;
            this.ppdShapes.Icon = ((System.Drawing.Icon)(resources.GetObject("ppdShapes.Icon")));
            this.ppdShapes.Name = "ppdShapes";
            this.ppdShapes.Visible = false;
            // 
            // pdShapes
            // 
            this.pdShapes.DocumentName = "Bar Chart";
            this.pdShapes.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.pdShapes_PrintPage);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 124);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnPreview);
            this.Name = "Form1";
            this.Text = "PrintWithPreview";
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button btnPrint;
        internal System.Windows.Forms.Button btnPreview;
        internal System.Windows.Forms.PrintPreviewDialog ppdShapes;
        internal System.Drawing.Printing.PrintDocument pdShapes;
    }
}

