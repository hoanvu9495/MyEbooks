﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace PrintWithPreview
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display the print preview.
        private void btnPreview_Click(object sender, EventArgs e)
        {
            m_NextPage = 0;
            ppdShapes.ShowDialog();
        }

        // Print without a preview.
        private void btnPrint_Click(object sender, EventArgs e)
        {
            m_NextPage = 0;
            pdShapes.Print();
        }

        // Generate a page of the printout.
        private int m_NextPage;

        private void pdShapes_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            int xmin = e.MarginBounds.Left;
            int ymin = e.MarginBounds.Top;
            int xmax = e.MarginBounds.Right;
            int ymax = e.MarginBounds.Bottom;
            int xmid = (int)(xmin + (xmax - xmin) / 2);
            int ymid = (int)(ymin + (ymax - ymin) / 2);

            // Draw a different shape for each page
            switch (m_NextPage)
	        {
                case 0:
                    // Draw a triangle.
                    Point[] pts = {
                        new Point(xmid, ymin),
                        new Point(xmax, ymax),
                        new Point(xmin, ymax)
                    };
                    using (Pen thick_pen = new Pen(Color.Blue, 10))
                    {
                        thick_pen.DashStyle = DashStyle.Dot;
                        e.Graphics.DrawPolygon(thick_pen, pts);
                    }
                    break;
                case 1:
                    // Draw an ellipse.
                    using (Pen thick_pen = new Pen(Color.Red, 10))
                    {
                        e.Graphics.DrawEllipse(thick_pen, e.MarginBounds);
                    }
                    break;
                case 2:
                    // Draw a rectangle.
                    using (Pen thick_pen = new Pen(Color.Green, 10))
                    {
                        thick_pen.DashStyle = DashStyle.Dash;
                        e.Graphics.DrawRectangle(thick_pen, e.MarginBounds);
                    }
                    break;
                case 3:
                    // Draw an X.
                    using (Pen thick_pen = new Pen(Color.Black, 10))
                    {
                        thick_pen.DashStyle = DashStyle.Custom;
                        thick_pen.DashPattern = new float[] {10, 10};
                        e.Graphics.DrawLine(thick_pen, xmin, ymin, xmax, ymax);
                        e.Graphics.DrawLine(thick_pen, xmin, ymax, xmax, ymin);
                    }
                    break;
	        }

            // Draw the page number.
            using (Font the_font = new Font("Times New Roman", 250, FontStyle.Bold, GraphicsUnit.Point))
            {
                using (StringFormat sf = new StringFormat())
                {
                    sf.Alignment = StringAlignment.Center;
                    sf.LineAlignment = StringAlignment.Center;
                    e.Graphics.DrawString(m_NextPage.ToString(),
                        the_font, Brushes.Black, xmid, ymid, sf);
                }
            }

            m_NextPage++;
            e.HasMorePages = (m_NextPage <= 3);
        }
    }
}
