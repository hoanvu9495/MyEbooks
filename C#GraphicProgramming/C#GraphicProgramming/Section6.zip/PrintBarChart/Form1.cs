﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace PrintBarChart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display the print preview.
        private void btnPreview_Click(object sender, EventArgs e)
        {
            // Display one row with three columns.
            ppdShapes.PrintPreviewControl.Columns = 3;
            ppdShapes.PrintPreviewControl.Rows = 1;

            // Make the dialog bigger.
            ppdShapes.Width = 640;

            // Display the dialog.
            ppdShapes.ShowDialog();
        }

        // Print without a preview.
        private void btnPrint_Click(object sender, EventArgs e)
        {
            pdShapes.Print();
        }

        // Data.
        private const int MIN_X = 0;
        private const int MAX_X = 500;
        private const int MIN_Y = 0;
        private const int MAX_Y = 400;
        private const int DX = 50;
        private Point[] sales_data = {
            new Point(0, 100),
            new Point(50, 200),
            new Point(100, 350),
            new Point(150, 250),
            new Point(200, 375),
            new Point(250, 100),
            new Point(300, 250),
            new Point(350, 200),
            new Point(400, 350),
            new Point(450, 300)
        };

        // Generate a page of the printout.
        private int m_NextPage;

        // Start with the first page.
        private void pdShapes_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            m_NextPage = 0;
        }

        // Draw the pages.
        private void pdShapes_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Set a transformation for this page.
            switch (m_NextPage)
	        {
                case 0:
                    // Centered.
                    CenterRectangles(e.Graphics,
                        MIN_X, MAX_X, MIN_Y, MAX_Y,
                        e.MarginBounds.Left, e.MarginBounds.Right,
                        e.MarginBounds.Top, e.MarginBounds.Bottom);
                    break;
                case 1:
                    // Fit.
                    FitRectangles(e.Graphics,
                        MIN_X, MAX_X, MIN_Y, MAX_Y,
                        e.MarginBounds.Left, e.MarginBounds.Right,
                        e.MarginBounds.Top, e.MarginBounds.Bottom);
                    break;
                case 2:
                    // Stretched.
                    MapRectangles(e.Graphics,
                        MIN_X, MAX_X, MIN_Y, MAX_Y,
                        e.MarginBounds.Left, e.MarginBounds.Right,
                        e.MarginBounds.Top, e.MarginBounds.Bottom);
                    break;
	        }

            // Draw the bar chart.
            DrawBarChart(e.Graphics);

            // Draw the margins.
            e.Graphics.ResetTransform();
            e.Graphics.DrawRectangle(Pens.Red, e.MarginBounds);

            // Clear the transformation just for safety//s sake.
            e.Graphics.ResetTransform();

            m_NextPage++;
            e.HasMorePages = (m_NextPage <= 2);
        }

        // Draw the data in world coordinates.
        private void DrawBarChart(Graphics gr)
        {
            using (Pen thin_pen = new Pen(Color.Green, 0))
            {
                // Draw the bars.
                foreach (Point pt in sales_data)
                {
                    gr.FillRectangle(Brushes.PaleGreen, pt.X, MAX_Y - pt.Y, DX, pt.Y);
                    gr.DrawRectangle(thin_pen, pt.X, MAX_Y - pt.Y, DX, pt.Y);
                }
            }

            // Draw a box around it all.
            gr.DrawRectangle(Pens.Blue, MIN_X, MIN_Y, MAX_X - MIN_X, MAX_Y - MIN_Y);
        }

        // Transform the Graphics object so
        // world  coordinates wxmin <= X <= wxmax, wymin <= Y <= wymax are mapped to 
        // device coordinates dxmin <= X <= dxmax, dymin <= Y <= dymax.
        private void MapRectangles(Graphics gr,
            float wxmin, float wxmax, float wymin, float wymax,
            float dxmin, float dxmax, float dymin, float dymax)
        {
            // Make a world coordinate rectangle.
            RectangleF wrectf = new RectangleF(wxmin, wymin, wxmax - wxmin, wymax - wymin);

            // Make PointF objects representing the upper left, upper right,
            // and lower right corners of device coordinates.
            PointF[] dpts = {
                new PointF(dxmin, dymin),
                new PointF(dxmax, dymin),
                new PointF(dxmin, dymax)
            };

            // Make the rectangle to the points.
            gr.Transform = new Matrix(wrectf, dpts);
        }

        // Transform the Graphics object to center
        // world  coordinates wxmin <= X <= wxmax, wymin <= Y <= wymax inside
        // device coordinates dxmin <= X <= dxmax, dymin <= Y <= dymax.
        private void CenterRectangles(Graphics gr,
            float wxmin, float wxmax, float wymin, float wymax,
            float dxmin, float dxmax, float dymin, float dymax)
        {
            // Figure out where we need to map in device coordinates.
            float wwid = wxmax - wxmin;
            float whgt = wymax - wymin;
            float dxmid = (dxmax + dxmin) / 2;
            float dymid = (dymax + dymin) / 2;

            dxmin = dxmid - wwid / 2;
            dxmax = dxmid + wwid / 2;
            dymin = dymid - whgt / 2;
            dymax = dymid + whgt / 2;

            // Map the rectangles.
            MapRectangles(gr, wxmin, wxmax, wymin, wymax, dxmin, dxmax, dymin, dymax);
        }

        // Transform the Graphics object to uniformly scale
        // world  coordinates wxmin <= X <= wxmax, wymin <= Y <= wymax to fit
        // device coordinates dxmin <= X <= dxmax, dymin <= Y <= dymax.
        private void FitRectangles(Graphics gr,
            float wxmin, float wxmax, float wymin, float wymax,
            float dxmin, float dxmax, float dymin, float dymax)
        {
            // Compare the world and device aspect ratios.
            float dxmid = (dxmax + dxmin) / 2;
            float dymid = (dymax + dymin) / 2;
            float wwid = wxmax - wxmin;
            float whgt = wymax - wymin;
            float dwid = dxmax - dxmin;
            float dhgt = dymax - dymin;
            float new_dwid, new_dhgt;
            if (wwid / whgt > dwid / dhgt)
            {
                // World rectangle is shorter/wider than device rectangle.
                // Make the result as wide as possible.
                new_dhgt = dwid * whgt / wwid;
                new_dwid = dwid;
            } else {
                // World rectangle is taller/thinner than device rectangle.
                // Make the result as tall as possible.
                new_dwid = dhgt * wwid / whgt;
                new_dhgt = dhgt;
            }

            dxmin = dxmid - new_dwid / 2;
            dxmax = dxmid + new_dwid / 2;
            dymin = dymid - new_dhgt / 2;
            dymax = dymid + new_dhgt / 2;

            // Map the rectangles.
            MapRectangles(gr, wxmin, wxmax, wymin, wymax, dxmin, dxmax, dymin, dymax);
        }
    }
}
