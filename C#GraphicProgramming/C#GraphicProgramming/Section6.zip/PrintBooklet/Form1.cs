﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;
using System.Drawing.Printing;

namespace PrintBooklet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Display the print preview.
        private void btnPreview_Click(object sender, EventArgs e)
        {
            ppdShapes.ShowDialog();
        }

        // Print without a preview.
        private void btnPrint_Click(object sender, EventArgs e)
        {
            pdShapes.Print();
        }

        // Printing variables.
        private bool m_IsPrinting;
        private int m_NextPage;

        // Generate a page of the printout.
        private void pdShapes_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            int xmin = e.MarginBounds.Left;
            int ymin = e.MarginBounds.Top;
            int xmax = e.MarginBounds.Right;
            int ymax = e.MarginBounds.Bottom;
            int xmid = (int)(xmin + (xmax - xmin) / 2);
            int ymid = (int)(ymin + (ymax - ymin) / 2);
            Color clr;

            // Draw a different shape for each page.
            switch (m_NextPage)
	        {
                case 0:
                    // Draw a triangle.
                    Point[] pts = {
                        new Point(xmid, ymin),
                        new Point(xmax, ymax),
                        new Point(xmin, ymax)
                    };
                    if (m_IsPrinting)
                    {
                        clr = Color.Black;
                    } else {
                        clr = Color.Blue;
                    }
                    using (Pen thick_pen = new Pen(clr, 10))
                    {
                        thick_pen.DashStyle = DashStyle.Dot;
                        e.Graphics.DrawPolygon(thick_pen, pts);
                    }
                    break;
                case 1:
                    // Draw an ellipse.
                    if (m_IsPrinting)
                    {
                        clr = Color.Black;
                    } else {
                        clr = Color.Red;
                    }
                    using (Pen thick_pen = new Pen(clr, 10))
                    {
                        e.Graphics.DrawEllipse(thick_pen, e.MarginBounds);
                    }
                    break;
                case 2:
                    // Draw a rectangle.
                    if (m_IsPrinting)
                    {
                        clr = Color.Black;
                    } else {
                        clr = Color.Green;
                    }
                    using (Pen thick_pen = new Pen(clr, 10))
                    {
                        thick_pen.DashStyle = DashStyle.Dash;
                        e.Graphics.DrawRectangle(thick_pen, e.MarginBounds);
                    }
                    break;
                case 3:
                    // Draw an X.
                    using (Pen thick_pen = new Pen(Color.Black, 10))
                    {
                        thick_pen.DashStyle = DashStyle.Custom;
                        thick_pen.DashPattern = new float[] {10, 10};
                        e.Graphics.DrawLine(thick_pen, xmin, ymin, xmax, ymax);
                        e.Graphics.DrawLine(thick_pen, xmin, ymax, xmax, ymin);
                    }
                    break;
            }

            // Draw the page number.
            using (Font the_font = new Font("Times new Roman", 250, FontStyle.Bold, GraphicsUnit.Point))
            {
                using (StringFormat sf = new StringFormat())
                {
                    sf.Alignment = StringAlignment.Center;
                    sf.LineAlignment = StringAlignment.Center;
                    e.Graphics.DrawString(m_NextPage.ToString(),
                        the_font, Brushes.Black, xmid, ymid, sf);
                }
            }

            // Draw a border if this is a preview.
            if (!m_IsPrinting)
            {
                e.Graphics.DrawRectangle(Pens.Red, e.MarginBounds);
            }

            m_NextPage++;
            e.HasMorePages = (m_NextPage <= 3);
        }

        private void pdShapes_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            // Remember whether we//re printing (as opposed to previewing).
            m_IsPrinting = (e.PrintAction == PrintAction.PrintToPrinter);

            // Start with the first page.
            m_NextPage = 0;
        }

        // Set an appropriate margin.
        private void pdShapes_QueryPageSettings(object sender, System.Drawing.Printing.QueryPageSettingsEventArgs e)
        {
            // Shift margins by 2 inches.
            const int MARGIN_WID = 200;

            if (m_NextPage == 0)
            {
                // First page. Large left margin.
                e.PageSettings.Margins.Left += MARGIN_WID;
            } else if (m_NextPage % 2 == 1) {
                // Odd page. Move margins left.
                e.PageSettings.Margins.Left -= MARGIN_WID;
                e.PageSettings.Margins.Right += MARGIN_WID;
            } else {
                // Even page. Move margins right.
                e.PageSettings.Margins.Left += MARGIN_WID;
                e.PageSettings.Margins.Right -= MARGIN_WID;
            }
        }
    }
}
