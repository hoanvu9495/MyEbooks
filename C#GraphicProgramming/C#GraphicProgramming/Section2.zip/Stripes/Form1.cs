﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace Stripes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw some shapes with striped lines.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (Pen the_pen = new Pen(Color.Red, 20))
            {
                Point[] pts = {
                    new Point(20, 20),
                    new Point(120, 20),
                    new Point(70, 120)
                };
                the_pen.CompoundArray = new float[] {0.0f, 0.4f, 0.6f, 1.0f};
                e.Graphics.DrawPolygon(the_pen, pts);

                the_pen.Color = Color.Green;
                the_pen.CompoundArray = new float[] {0.0f, 0.1f, 0.3f, 0.7f, 0.9f, 1.0f};
                e.Graphics.DrawEllipse(the_pen, 150, 20, 100, 150);
            }
        }
    }
}
