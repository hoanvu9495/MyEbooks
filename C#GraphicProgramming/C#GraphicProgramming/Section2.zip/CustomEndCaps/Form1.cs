﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace CustomEndCaps
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw lines with custom end caps.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            using (Pen the_pen = new Pen(Color.Green, 5))
            {
                // Define the start cap.
                Point[] start_pts = {
                    new Point(0, 0),
                    new Point(-3, 3),
                    new Point(3, 3),
                    new Point(0, 0)
                };
                GraphicsPath start_path = new GraphicsPath();
                start_path.AddLines(start_pts);
                CustomLineCap start_cap = new CustomLineCap(null, start_path);
                the_pen.CustomStartCap = start_cap;

                // Define the end cap.
                Point[] end_pts = {
                    new Point(0, 0),
                    new Point(-3, 0),
                    new Point(-3, 3),
                    new Point(3, 3)
                };
                GraphicsPath end_path = new GraphicsPath();
                end_path.AddLines(end_pts);
                CustomLineCap end_cap = new CustomLineCap(null, end_path);
                the_pen.CustomEndCap = end_cap;

                // Draw a sample.
                e.Graphics.DrawLine(the_pen, 50, 50, 100, 100);

                end_cap.Dispose();
                end_path.Dispose();
                start_cap.Dispose();
                start_path.Dispose();
            }
        }
    }
}
