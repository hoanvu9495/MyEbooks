﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace LinearGradientBrushes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Fill a rectangle with a linear gradient brush.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Draw with a horizontal gradient.
            Rectangle rect1 = new Rectangle(20, 20, 250, 100);
            using (LinearGradientBrush br = new LinearGradientBrush(
                rect1, Color.Red, Color.Blue, LinearGradientMode.Horizontal))
            {
                e.Graphics.FillRectangle(br, rect1);
                e.Graphics.DrawRectangle(Pens.Black, rect1);
            }

            // Draw with a horizontal gradient.
            Rectangle rect2 = new Rectangle(20, 140, 250, 100);
            using (LinearGradientBrush br = new LinearGradientBrush(
             rect2, Color.Red, Color.Blue, LinearGradientMode.Horizontal))
             {
                // Define a rainbow blend.
                ColorBlend color_blend = new ColorBlend();
                color_blend.Colors = new Color[]
                    {Color.Red, Color.Orange, Color.Yellow,
                     Color.Lime, Color.Blue, Color.Indigo, Color.DarkViolet};
                color_blend.Positions = new float[]
                    {0 / 6f, 1 / 6f, 2 / 6f, 3 / 6f, 4 / 6f, 5 / 6f, 6 / 6f};
                br.InterpolationColors = color_blend;

                // Fill a rectangle with the blended brush.
                e.Graphics.FillRectangle(br, rect2);
                e.Graphics.DrawRectangle(Pens.Black, rect2);
            }
        }
    }
}
