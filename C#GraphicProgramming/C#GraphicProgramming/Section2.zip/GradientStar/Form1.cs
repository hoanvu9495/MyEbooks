﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace GradientStar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.ResizeRedraw, true);
        }

        // Draw a star filled with a path gradient brush.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Define the points.
            float rx1 = (float)(this.ClientSize.Width * 0.45);
            float rx2 = (float)(this.ClientSize.Width * 0.25);
            float ry1 = (float)(this.ClientSize.Height * 0.45);
            float ry2 = (float)(this.ClientSize.Height * 0.25);
            float cx = (float)(this.ClientSize.Width / 2);
            float cy = (float)(this.ClientSize.Height / 2);
            PointF[] pts = new PointF[10];
            float theta = 0;
            float dtheta = (float)(Math.PI / 5);
            for (int i = 0; i <= 9; i += 2)
            {
                pts[i] = new PointF(
                    (float)(cx + rx1 * Math.Cos(theta)), 
                    (float)(cy + ry1 * Math.Sin(theta)));
                theta += dtheta;
                pts[i + 1] = new PointF(
                    (float)(cx + rx2 * Math.Cos(theta)), 
                    (float)(cy + ry2 * Math.Sin(theta)));
                theta += dtheta;
            }

            // Make a path gradient brush.
            using (PathGradientBrush br = new PathGradientBrush(pts))
            {
                br.CenterPoint = new PointF(cx, cy);
                br.CenterColor = Color.White;
                br.SurroundColors = new Color[] {
                    Color.Red, Color.Blue, Color.Red, Color.Blue, Color.Red,
                    Color.Blue, Color.Red, Color.Blue, Color.Red, Color.Blue
                };

                // Fill the star.
                e.Graphics.FillPolygon(br, pts);
            }

            // Outline the star.
            e.Graphics.DrawPolygon(Pens.Black, pts);
        }
    }
}
