﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace CustomDash
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw some custom dash patterns.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            using (Pen the_pen = new Pen(Color.Blue))
            {
                int y = 10;

                // Standard dot.
                the_pen.DashStyle = DashStyle.Dot;
                e.Graphics.DrawLine(the_pen, 10, y, 250, y);
                y += 15;

                // Standard dash.
                the_pen.DashStyle = DashStyle.Dash;
                e.Graphics.DrawLine(the_pen, 10, y, 250, y);
                y += 15;

                // Thin with long dashes.
                the_pen.DashStyle = DashStyle.Custom;
                the_pen.DashPattern = new float[] {10, 2};
                e.Graphics.DrawLine(the_pen, 10, y, 250, y);
                y += 15;

                // Thick with the same absolute dash lengths.
                the_pen.Width = 5;
                the_pen.DashStyle = DashStyle.Custom;
                the_pen.DashPattern = new float[] { 2f, 0.4f };
                e.Graphics.DrawLine(the_pen, 10, y, 250, y);
                y += 15;

                // Thick with the same relative dash lengths.
                the_pen.Width = 5;
                the_pen.DashStyle = DashStyle.Custom;
                the_pen.DashPattern = new float[] {10f, 2f};
                e.Graphics.DrawLine(the_pen, 10, y, 250, y);
                y += 15;

                // Thick Dash Dash Dot Dot.
                the_pen.Width = 5;
                the_pen.DashStyle = DashStyle.Custom;
                the_pen.DashPattern = new float[] {5f, 2f, 5f, 2f, 2f, 2f, 2f, 2f};
                e.Graphics.DrawLine(the_pen, 10, y, 250, y);
                y += 15;
            }
        }
    }
}
