﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SimpleText
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw some text.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            int x = 10;
            int y = 10;

            using (Font the_font = new Font("Times New Roman", 20, FontStyle.Bold, GraphicsUnit.Point))
            {
                e.Graphics.DrawString("SimpleText", the_font, Brushes.Blue, x, y);
                SizeF text_size = e.Graphics.MeasureString("SimpleText", the_font);
                e.Graphics.DrawRectangle(Pens.Red, x, y, text_size.Width, text_size.Height);
                y += (int)text_size.Height;
            }

            using (Font the_font = new Font("Comic Sans MS", 20, FontStyle.Regular, GraphicsUnit.Point))
            {
                e.Graphics.DrawString("SimpleText", the_font, Brushes.Blue, x, y);
                SizeF text_size = e.Graphics.MeasureString("SimpleText", the_font);
                e.Graphics.DrawRectangle(Pens.Red, x, y, text_size.Width, text_size.Height);
                y += (int)text_size.Height;
            }

            using (Font the_font = new Font("Arial", 20, FontStyle.Italic | FontStyle.Bold, GraphicsUnit.Point))
            {
                e.Graphics.DrawString("SimpleText", the_font, Brushes.Blue, x, y);
                SizeF text_size = e.Graphics.MeasureString("SimpleText", the_font);
                e.Graphics.DrawRectangle(Pens.Red, x, y, text_size.Width, text_size.Height);
                y += (int)text_size.Height;
            }
        }
    }
}
