﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Text;

namespace WrappedText
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private const string SAMPLE_TEXT =
            "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent et nunc at erat commodo placerat. Suspendisse semper. In pharetra, ante eget cursus hendrerit, leo diam congue tellus, sit amet aliquam risus purus sit amet enim. Aenean ac nulla eget pede porta malesuada. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Fusce tincidunt, nisi eu placerat eleifend, urna ligula rhoncus nulla, et ultrices velit tortor in lectus. Suspendisse potenti. Maecenas ipsum augue, consectetuer at, tincidunt ut, mollis ac, felis. Sed eros massa, porttitor sed, blandit pulvinar, congue id, elit. Sed nec lorem. Aliquam sit amet enim id ligula molestie sagittis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam erat volutpat. Fusce dui mauris, rutrum ut, auctor ultricies, lobortis et, justo.\n" +
            "Suspendisse scelerisque tellus ac leo. Nullam ac ipsum quis risus vestibulum volutpat. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Fusce tortor diam, dapibus sed, lacinia eu, porta commodo, purus. Nunc nulla metus, cursus id, sollicitudin quis, pellentesque eu, est. Vestibulum pellentesque eros. Donec fringilla. Vestibulum bibendum. Curabitur lobortis orci quis lectus. In sed ligula vel felis ullamcorper pellentesque. Duis est. Suspendisse potenti. Donec convallis libero a ante. Pellentesque fringilla ipsum at arcu. Aliquam molestie, elit in imperdiet mollis, lorem magna imperdiet felis, eu gravida neque sapien at augue. Maecenas ac magna eget neque rhoncus fermentum. Nulla suscipit, lacus at rhoncus pretium, metus risus blandit turpis, nec dignissim sem risus eget dui. Nulla facilisi. In neque odio, eleifend eu, convallis et, euismod vel, nulla. Maecenas sapien mauris, aliquet a, venenatis at, auctor vitae, enim.\n" +
            "In hac habitasse platea dictumst. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec tempor augue quis leo. Suspendisse potenti. Suspendisse potenti. Etiam tortor purus, accumsan non, consequat id, elementum id, sem. Fusce vehicula dignissim lacus. Aliquam sollicitudin elit vel urna. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Mauris nisi tellus, adipiscing sit amet, vestibulum et, accumsan eget, sapien. Sed in eros vel leo tempor pretium. Cras cursus lacus sed dui. Phasellus tempor elit ac augue. Aliquam erat volutpat. Pellentesque fringilla urna quis arcu. Praesent elementum dictum massa.\n" +
            "Suspendisse rutrum eros at metus. Proin eget mauris at turpis congue consequat. Nam nec nunc id ipsum tempus mollis. Proin a lorem. Suspendisse adipiscing neque nec turpis. Nullam pellentesque, tortor non commodo tristique, felis eros egestas tellus, id interdum massa lectus ac eros. In scelerisque. Vestibulum sagittis libero at lorem. Morbi accumsan egestas lorem. Curabitur sagittis est sit amet dolor. Aliquam accumsan elementum mi. Morbi sed massa. Morbi ut leo. Vivamus libero dui, ultricies egestas, lobortis in, congue sed, massa. Suspendisse potenti. Nunc facilisis dictum sapien. Quisque convallis urna nec neque dapibus auctor. Praesent lacinia.\n" +
            "Nulla facilisi. Nam elit. Morbi ac lacus eu urna pellentesque ultricies. Cras lacus. Vestibulum euismod ornare sapien. Nullam imperdiet libero eu tortor. Aenean congue. Aenean viverra dui vel ante. Nunc lorem eros, ultricies nec, aliquet eu, facilisis sed, quam. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.";

        private void Form1_Load(object sender, EventArgs e)
        {
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.ResizeRedraw, true);
        }

        // Draw some text wrapped to fill the form.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(this.BackColor);
            e.Graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

            // Make a margin rectangle.
            Rectangle rect = new Rectangle(10, 10, this.ClientSize.Width - 20, this.ClientSize.Height - 20);

            // Draw the text inside the rectangle.
            using (Font the_font = new Font("Times New Roman", 20, FontStyle.Regular, GraphicsUnit.Point))
            {
                e.Graphics.DrawString(SAMPLE_TEXT, the_font, Brushes.Black, rect);
                e.Graphics.DrawRectangle(Pens.Blue, rect);
            }
        }
    }
}
