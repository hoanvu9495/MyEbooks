﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace HatchBrushes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private const int WID = 50;
        private const int HGT = 30;
        private const int GAP = 20;

        private void Form1_Load(object sender, EventArgs e)
        {
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.ResizeRedraw, true);
            this.UpdateStyles();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(this.BackColor);

            int x = (int)(GAP / 2);
            int y = (int)(GAP / 2);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.BackwardDiagonal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Cross);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.DarkDownwardDiagonal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.DarkHorizontal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.DarkUpwardDiagonal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.DarkVertical);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.DashedDownwardDiagonal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.DashedHorizontal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.DashedUpwardDiagonal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.DashedVertical);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.DiagonalBrick);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.DiagonalCross);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Divot);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.DottedDiamond);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.DottedGrid);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.ForwardDiagonal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Horizontal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.HorizontalBrick);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.LargeCheckerBoard);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.LargeConfetti);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.LargeGrid);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.LightDownwardDiagonal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.LightHorizontal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.LightUpwardDiagonal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.LightVertical);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Max);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Min);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.NarrowHorizontal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.NarrowVertical);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.OutlinedDiamond);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Percent05);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Percent10);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Percent20);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Percent25);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Percent30);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Percent40);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Percent50);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Percent60);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Percent70);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Percent75);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Percent80);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Percent90);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Plaid);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Shingle);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.SmallCheckerBoard);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.SmallConfetti);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.SmallGrid);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.SolidDiamond);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Sphere);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Trellis);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Vertical);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Wave);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.Weave);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.WideDownwardDiagonal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.WideUpwardDiagonal);
            DrawSample(e.Graphics, ref x, ref y, HatchStyle.ZigZag);
        }

        private void DrawSample(Graphics gr, ref int x, ref int y, HatchStyle style)
        {
            using (HatchBrush br = new HatchBrush(style, Color.Blue, Color.Yellow))
            {
                gr.FillRectangle(br, x, y, WID, HGT);
            }

            y += HGT + GAP;
            if (y + HGT > this.ClientSize.Height)
            {
                y = (int)(GAP / 2);
                x += WID + GAP;
            }
        }
    }
}
