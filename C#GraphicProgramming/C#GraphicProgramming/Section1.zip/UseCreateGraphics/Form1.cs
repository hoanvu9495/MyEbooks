﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UseCreateGraphics
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            Graphics gr = this.CreateGraphics();
            gr.FillEllipse(Brushes.Yellow, 10, 30, 200, 150);
            gr.DrawEllipse(Pens.Orange, 10, 30, 200, 150);
        }
    }
}
