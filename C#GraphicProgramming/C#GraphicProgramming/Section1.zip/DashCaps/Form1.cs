﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace DashCaps
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            int y = 20;

            using (Pen the_pen = new Pen(Color.Blue, 10))
            {
                the_pen.DashStyle = DashStyle.Dash;
                the_pen.DashCap = DashCap.Triangle;
                e.Graphics.DrawLine(the_pen, 20, y, 170, y);
                y += 20;

                the_pen.DashStyle = DashStyle.DashDot;
                the_pen.DashCap = DashCap.Flat;
                e.Graphics.DrawLine(the_pen, 20, y, 170, y);
                y += 20;

                the_pen.DashStyle = DashStyle.DashDotDot;
                the_pen.DashCap = DashCap.Round;
                e.Graphics.DrawLine(the_pen, 20, y, 170, y);
                y += 20;

                the_pen.DashOffset = 1;
                y += 20;

                the_pen.DashStyle = DashStyle.Dash;
                the_pen.DashCap = DashCap.Triangle;
                e.Graphics.DrawLine(the_pen, 20, y, 170, y);
                y += 20;

                the_pen.DashStyle = DashStyle.DashDot;
                the_pen.DashCap = DashCap.Flat;
                e.Graphics.DrawLine(the_pen, 20, y, 170, y);
                y += 20;

                the_pen.DashStyle = DashStyle.DashDotDot;
                the_pen.DashCap = DashCap.Round;
                e.Graphics.DrawLine(the_pen, 20, y, 170, y);
                y += 20;
            }
        }
    }
}
