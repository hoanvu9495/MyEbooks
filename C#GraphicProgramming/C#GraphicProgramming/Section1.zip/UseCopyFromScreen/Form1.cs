﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UseCopyFromScreen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            int x = int.Parse(txtXmin.Text);
            int y = int.Parse(txtYmin.Text);
            int wid = int.Parse(txtXmax.Text) - x + 1;
            int hgt = int.Parse(txtYmax.Text) - y + 1;

            Bitmap bm = new Bitmap(wid, hgt);
            using (Graphics gr = Graphics.FromImage(bm))
            {
                gr.CopyFromScreen(x, y, 0, 0, new Size(wid, hgt));
            }

            picResult.Image = bm;
        }
    }
}
