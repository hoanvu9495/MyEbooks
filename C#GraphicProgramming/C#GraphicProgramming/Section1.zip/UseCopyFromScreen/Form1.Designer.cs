﻿namespace UseCopyFromScreen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picResult = new System.Windows.Forms.PictureBox();
            this.btnCopy = new System.Windows.Forms.Button();
            this.txtYmax = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.txtYmin = new System.Windows.Forms.TextBox();
            this.txtXmax = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.txtXmin = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picResult)).BeginInit();
            this.SuspendLayout();
            // 
            // picResult
            // 
            this.picResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picResult.Location = new System.Drawing.Point(8, 56);
            this.picResult.Name = "picResult";
            this.picResult.Size = new System.Drawing.Size(40, 40);
            this.picResult.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picResult.TabIndex = 19;
            this.picResult.TabStop = false;
            // 
            // btnCopy
            // 
            this.btnCopy.Location = new System.Drawing.Point(184, 16);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(75, 23);
            this.btnCopy.TabIndex = 18;
            this.btnCopy.Text = "Copy";
            this.btnCopy.UseVisualStyleBackColor = true;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // txtYmax
            // 
            this.txtYmax.Location = new System.Drawing.Point(128, 32);
            this.txtYmax.Name = "txtYmax";
            this.txtYmax.Size = new System.Drawing.Size(40, 20);
            this.txtYmax.TabIndex = 17;
            this.txtYmax.Text = "300";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(96, 32);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(16, 13);
            this.Label4.TabIndex = 16;
            this.Label4.Text = "to";
            // 
            // txtYmin
            // 
            this.txtYmin.Location = new System.Drawing.Point(40, 32);
            this.txtYmin.Name = "txtYmin";
            this.txtYmin.Size = new System.Drawing.Size(40, 20);
            this.txtYmin.TabIndex = 15;
            this.txtYmin.Text = "100";
            // 
            // txtXmax
            // 
            this.txtXmax.Location = new System.Drawing.Point(128, 8);
            this.txtXmax.Name = "txtXmax";
            this.txtXmax.Size = new System.Drawing.Size(40, 20);
            this.txtXmax.TabIndex = 14;
            this.txtXmax.Text = "300";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(96, 8);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(16, 13);
            this.Label3.TabIndex = 13;
            this.Label3.Text = "to";
            // 
            // txtXmin
            // 
            this.txtXmin.Location = new System.Drawing.Point(40, 8);
            this.txtXmin.Name = "txtXmin";
            this.txtXmin.Size = new System.Drawing.Size(40, 20);
            this.txtXmin.TabIndex = 12;
            this.txtXmin.Text = "100";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(8, 32);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(17, 13);
            this.Label2.TabIndex = 11;
            this.Label2.Text = "Y:";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(8, 8);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(17, 13);
            this.Label1.TabIndex = 10;
            this.Label1.Text = "X:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 264);
            this.Controls.Add(this.picResult);
            this.Controls.Add(this.btnCopy);
            this.Controls.Add(this.txtYmax);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.txtYmin);
            this.Controls.Add(this.txtXmax);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.txtXmin);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Name = "Form1";
            this.Text = "UseCopyFromScreen";
            ((System.ComponentModel.ISupportInitialize)(this.picResult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.PictureBox picResult;
        internal System.Windows.Forms.Button btnCopy;
        internal System.Windows.Forms.TextBox txtYmax;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox txtYmin;
        internal System.Windows.Forms.TextBox txtXmax;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox txtXmin;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
    }
}

