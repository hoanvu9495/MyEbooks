﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TextureTests
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Fill some rectangles with different origins.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            int wid = Properties.Resources.smile.Width;
            int hgt = Properties.Resources.smile.Height;

            using (TextureBrush br = new TextureBrush(Properties.Resources.smile))
            {
                e.Graphics.FillRectangle(br, 30, 30, wid, hgt);
                e.Graphics.DrawRectangle(Pens.Red, 30, 30, wid, hgt);

                br.TranslateTransform(150, 30);
                e.Graphics.FillRectangle(br, 150, 30, wid, hgt);
                e.Graphics.DrawRectangle(Pens.Red, 150, 30, wid, hgt);
            }
        }
    }
}
