﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace StockBrushes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Fill an ellipse.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.FillEllipse(Brushes.Yellow, 20, 20, 200, 150);

            // Outline the ellipse.
            using (Pen the_pen = new Pen(Color.Orange, 5))
            {
                e.Graphics.DrawEllipse(the_pen, 20, 20, 200, 150);
            }
        }
    }
}
