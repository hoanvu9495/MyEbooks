﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace HatchedRectangle
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw a hatched rectangle.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            using (HatchBrush br = new HatchBrush(HatchStyle.DiagonalBrick, Color.Red, Color.Pink))
            {
                e.Graphics.FillRectangle(br, 10, 10, 200, 150);
                e.Graphics.DrawRectangle(Pens.Red, 10, 10, 200, 150);
            }
        }
    }
}
