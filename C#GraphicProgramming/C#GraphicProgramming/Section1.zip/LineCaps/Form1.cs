﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace LineCaps
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            int y = 50;

            using (Pen the_pen = new Pen(Color.Blue, 10))
            {
                DrawSample(e.Graphics, ref y, LineCap.ArrowAnchor);
                DrawSample(e.Graphics, ref y, LineCap.DiamondAnchor);
                DrawSample(e.Graphics, ref y, LineCap.Flat);
                DrawSample(e.Graphics, ref y, LineCap.Round);
                DrawSample(e.Graphics, ref y, LineCap.RoundAnchor);
                DrawSample(e.Graphics, ref y, LineCap.Square);
                DrawSample(e.Graphics, ref y, LineCap.SquareAnchor);
                DrawSample(e.Graphics, ref y, LineCap.Triangle);
            }
        }

        private void DrawSample(Graphics gr, ref int y, LineCap line_cap)
        {
            using (Pen the_pen = new Pen(Color.Blue, 10))
            {
                the_pen.EndCap = line_cap;
                the_pen.StartCap = line_cap;
                gr.DrawLine(the_pen, 50, y, 250, y);
                y += 25;
            }
        }
    }
}
