﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace UsePens
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Draw some pen samples.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawRectangle(Pens.Green, 10, 10, 100, 50);

            using (Pen the_pen = new Pen(Color.Orange, 10))
            {
                e.Graphics.DrawLine(the_pen, 30, 30, 200, 30);
            }

            using (Brush br = new LinearGradientBrush(
                new Point(20, 100), new Point(170, 200),
                Color.Red, Color.Blue))
            {
                using (Pen the_pen = new Pen(br, 10))
                {
                    e.Graphics.DrawEllipse(the_pen,
                        20, 100, 150, 100);
                }
            }

            Point[] pts = {
                new Point(250, 50),
                new Point(220, 100),
                new Point(270, 150),
                new Point(200, 170),
                new Point(180, 80),
                new Point(210, 30)
            };
            using (Pen the_pen = new Pen(Color.Purple, 5))
            {
                the_pen.DashStyle = DashStyle.Dash;
                e.Graphics.DrawPolygon(the_pen, pts);
            }
        }
    }
}
