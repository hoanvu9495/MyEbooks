﻿namespace SimplePrint
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnPrintPreview = new System.Windows.Forms.Button();
            this.pdEllipse = new System.Drawing.Printing.PrintDocument();
            this.ppdEllipse = new System.Windows.Forms.PrintPreviewDialog();
            this.SuspendLayout();
            // 
            // btnPrintPreview
            // 
            this.btnPrintPreview.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPrintPreview.Location = new System.Drawing.Point(94, 65);
            this.btnPrintPreview.Name = "btnPrintPreview";
            this.btnPrintPreview.Size = new System.Drawing.Size(96, 32);
            this.btnPrintPreview.TabIndex = 2;
            this.btnPrintPreview.Text = "Print Preview";
            this.btnPrintPreview.Click += new System.EventHandler(this.btnPrintPreview_Click);
            // 
            // pdEllipse
            // 
            this.pdEllipse.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.pdEllipse_PrintPage);
            // 
            // ppdEllipse
            // 
            this.ppdEllipse.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.ppdEllipse.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.ppdEllipse.ClientSize = new System.Drawing.Size(400, 300);
            this.ppdEllipse.Document = this.pdEllipse;
            this.ppdEllipse.Enabled = true;
            this.ppdEllipse.Icon = ((System.Drawing.Icon)(resources.GetObject("ppdEllipse.Icon")));
            this.ppdEllipse.Name = "ppdEllipse";
            this.ppdEllipse.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 162);
            this.Controls.Add(this.btnPrintPreview);
            this.Name = "Form1";
            this.Text = "SimplePrint";
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button btnPrintPreview;
        internal System.Drawing.Printing.PrintDocument pdEllipse;
        internal System.Windows.Forms.PrintPreviewDialog ppdEllipse;
    }
}

