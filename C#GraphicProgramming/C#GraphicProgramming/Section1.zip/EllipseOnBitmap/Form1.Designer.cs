﻿namespace EllipseOnBitmap
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDraw = new System.Windows.Forms.Button();
            this.picEllipse = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picEllipse)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDraw
            // 
            this.btnDraw.Location = new System.Drawing.Point(8, 8);
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(75, 23);
            this.btnDraw.TabIndex = 5;
            this.btnDraw.Text = "Draw";
            this.btnDraw.Click += new System.EventHandler(this.btnDraw_Click);
            // 
            // picEllipse
            // 
            this.picEllipse.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picEllipse.Location = new System.Drawing.Point(8, 40);
            this.picEllipse.Name = "picEllipse";
            this.picEllipse.Size = new System.Drawing.Size(40, 40);
            this.picEllipse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picEllipse.TabIndex = 4;
            this.picEllipse.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 264);
            this.Controls.Add(this.btnDraw);
            this.Controls.Add(this.picEllipse);
            this.Name = "Form1";
            this.Text = "EllipseOnBitmap";
            ((System.ComponentModel.ISupportInitialize)(this.picEllipse)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btnDraw;
        internal System.Windows.Forms.PictureBox picEllipse;
    }
}

