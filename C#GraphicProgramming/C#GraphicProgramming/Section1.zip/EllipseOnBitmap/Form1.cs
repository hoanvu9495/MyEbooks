﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EllipseOnBitmap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            // Create the Bitmap.
            Bitmap bm = new Bitmap(200, 100);

            // Get a Graphics object associated with the Bitmap.
            Graphics gr = Graphics.FromImage(bm);

            // Draw on the Bitmap.
            gr.FillEllipse(Brushes.Pink, 10, 10, 180, 80);
            gr.DrawEllipse(Pens.Black, 10, 10, 180, 80);

            // Display the Bitmap in the PictureBox.
            picEllipse.Image = bm;
        }
    }
}
