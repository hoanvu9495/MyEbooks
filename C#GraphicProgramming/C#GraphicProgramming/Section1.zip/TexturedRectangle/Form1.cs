﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TexturedRectangle
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.ClientSize = new Size(
                4 * Properties.Resources.smile.Width,
                3 * Properties.Resources.smile.Height);
        }

        // Fill an area with a texture.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            using (TextureBrush br = new TextureBrush(Properties.Resources.smile))
            {
                e.Graphics.FillRectangle(br, this.ClientRectangle);
            }
        }
    }
}
